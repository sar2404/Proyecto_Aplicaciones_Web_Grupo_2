package com.foodorder.service;

import com.foodorder.model.*;
import com.foodorder.repository.PedidoRepository;
import com.foodorder.repository.ProductoRepository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final ProductoRepository productoRepository;

    public PedidoService(PedidoRepository pedidoRepository,
                         ProductoRepository productoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.productoRepository = productoRepository;
    }

    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedido buscarPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Pedido no encontrado"));
    }

    @Transactional
    public Pedido crearPedido(Usuario usuario,
                              Map<Long, Integer> carrito) {

        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setEstado("Pendiente");

        BigDecimal total = BigDecimal.ZERO;

        for (Map.Entry<Long, Integer> item : carrito.entrySet()) {

            Producto producto = productoRepository.findById(item.getKey())
                    .orElseThrow(() ->
                            new IllegalArgumentException("Producto no encontrado"));

            int cantidad = item.getValue();

            if (cantidad <= 0 ||
                    !Boolean.TRUE.equals(producto.getEstado())) {
                throw new IllegalArgumentException(
                        "Producto no disponible o cantidad inválida");
            }

            BigDecimal precio = BigDecimal.valueOf(producto.getPrecio());

            BigDecimal subtotal = precio.multiply(
                    BigDecimal.valueOf(cantidad));

            DetallePedido detalle = new DetallePedido();

            detalle.setPedido(pedido);
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setSubtotal(subtotal);

            pedido.getDetalles().add(detalle);

            total = total.add(subtotal);
        }

        pedido.setTotal(total);

        return pedidoRepository.save(pedido);
    }

    public Pedido actualizarEstado(Long id, String estado) {

        Pedido pedido = buscarPorId(id);

        if (!List.of("Pendiente", "En preparación",
                "Listo", "Entregado").contains(estado)) {

            throw new IllegalArgumentException("Estado no válido");
        }

        pedido.setEstado(estado);

        return pedidoRepository.save(pedido);
    }

    public List<Pedido> listarPedidosUsuario(Usuario usuario) {
        return pedidoRepository.findByUsuarioOrderByFechaDesc(usuario);
    }

    public Object listarPedidosUsuario(Usuario usuario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}