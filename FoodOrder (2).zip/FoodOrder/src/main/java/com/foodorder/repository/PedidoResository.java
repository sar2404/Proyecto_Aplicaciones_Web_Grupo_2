package com.foodorder.repository;

import com.foodorder.model.Pedido;
import com.foodorder.model.Usuario;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByUsuarioOrderByFechaDesc(Usuario usuario);
}