package com.foodorder.controller;

import com.foodorder.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final ProductoService productoService;

    public HomeController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping({"/", "/inicio"})
    public String inicio(Model model) {

        model.addAttribute("productos",
                productoService.listarProductos()
                .stream()
                .filter(p -> Boolean.TRUE.equals(p.getEstado()))
                .toList());

        return "inicio";
    }
}