package com.foodorder.controller;

import com.foodorder.model.Usuario;
import com.foodorder.service.PedidoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HistorialController {

    private final PedidoService pedidoService;

    public HistorialController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping("/mis-pedidos")
    public String historial(HttpSession session, Model model) {

        Usuario usuario = (Usuario)
                session.getAttribute("usuarioLogueado");

        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("pedidos",
                pedidoService.listarPedidosUsuario(usuario));

        return "historial";
    }
}
