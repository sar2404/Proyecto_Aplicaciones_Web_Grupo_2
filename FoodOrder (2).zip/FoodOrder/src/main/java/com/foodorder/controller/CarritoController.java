package com.foodorder.controller;

import com.foodorder.model.Producto;
import com.foodorder.service.ProductoService;
import com.foodorder.service.PedidoService;
import jakarta.servlet.http.HttpSession;
import java.util.Map;
import java.util.LinkedHashMap;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/carrito")
public class CarritoController {

    private final ProductoService productoService;
    private final PedidoService pedidoService;

    public CarritoController(ProductoService productoService,
                             PedidoService pedidoService) {
        this.productoService = productoService;
        this.pedidoService = pedidoService;
    }

    @SuppressWarnings("unchecked")
    private Map<Long, Integer> obtenerCarrito(HttpSession session) {
        Map<Long, Integer> carrito =
                (Map<Long, Integer>) session.getAttribute("carrito");

        if (carrito == null) {
            carrito = new LinkedHashMap<>();
            session.setAttribute("carrito", carrito);
        }

        return carrito;
    }

    @PostMapping("/agregar/{id}")
    public String agregar(@PathVariable Long id,
                          HttpSession session) {

        Producto producto = productoService.buscarPorId(id);

        if (Boolean.TRUE.equals(producto.getEstado())) {
            Map<Long, Integer> carrito = obtenerCarrito(session);
            carrito.merge(id, 1, Integer::sum);
        }

        return "redirect:/carrito";
    }

    @GetMapping
    public String mostrar(HttpSession session, Model model) {

        Map<Long, Integer> carrito = obtenerCarrito(session);

        model.addAttribute("carrito", carrito);
        model.addAttribute("productos",
                productoService.listarProductos());

        return "carrito";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id,
                           HttpSession session) {

        obtenerCarrito(session).remove(id);

        return "redirect:/carrito";
    }

    @PostMapping("/vaciar")
    public String vaciar(HttpSession session) {
        obtenerCarrito(session).clear();
        return "redirect:/carrito";
    }

    @PostMapping("/confirmar")
    public String confirmar(HttpSession session) {

        Object objetoUsuario = session.getAttribute("usuarioLogueado");

        if (objetoUsuario == null) {
            return "redirect:/login";
        }

        Map<Long, Integer> carrito = obtenerCarrito(session);

        if (carrito.isEmpty()) {
            return "redirect:/carrito";
        }

        pedidoService.crearPedido(
                (com.foodorder.model.Usuario) objetoUsuario,
                carrito);

        carrito.clear();

        return "redirect:/mis-pedidos";
    }
}