package com.foodorder.controller;

import com.foodorder.service.PedidoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("pedidos",
                pedidoService.listarPedidos());
        return "pedidos";
    }

    @PostMapping("/estado/{id}")
    public String actualizarEstado(
            @PathVariable Long id,
            @RequestParam String estado) {

        pedidoService.actualizarEstado(id, estado);

        return "redirect:/pedidos";
    }
}