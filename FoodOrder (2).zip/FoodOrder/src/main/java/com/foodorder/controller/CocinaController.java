package com.foodorder.controller;

import com.foodorder.service.PedidoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CocinaController {

    private final PedidoService pedidoService;

    public CocinaController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping("/cocina")
    public String cocina(Model model) {
        model.addAttribute("pedidos",
                pedidoService.listarPedidos());
        return "pedidos";
    }
}
